Chép các file IPA bạn có quyền chia sẻ vào thư mục này.
